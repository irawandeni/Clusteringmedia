<div class="datatable-ajax-source">
  
        <h2 class="text-center">Tabel Data bank</h2>
 
                                <table id="datatables" class="table_bank table table-bordered table-condensed table-striped" style="">
                                    <thead class="">
                                        <tr>
                                                       
                                                        <th>Bukti</th>
                                                        
                                                        <th>D/K</th>
                                                        <th>Akun</th>
                                                        <th>Rekening Bank</th>
                                                        <th>Supplier</th>
                                                        <th>Tanggal</th>
                                                        
                                                        <th>Total</th>
                                                   
                                                        <th>Aksi</th>

                                                    </tr>
                                    </thead>

                                    <tbody class="table-bordered">
                                        <tr>
                                            <td colspan="14" class="text-center dataTables_empty"><img src="<?php echo assets_url('images/loader.gif');  ?>" title="Loading" alt="Loading">&nbsp;&nbsp; Loading data, please wait....</td>
                                            
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>