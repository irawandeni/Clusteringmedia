<div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-md-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Form Siklus</h5>
                        
                    </div>
                    <div class="ibox-content">
                    <?php $this->load->view('siklus_table') ?>


                    </div>
                </div>
                </div>
               
            </div>
          
            
</div>

