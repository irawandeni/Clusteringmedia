		<div class="row" style="margin-top:30px;">
			
        	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<?php if(!isset($data)): ?>
					<div class="jumbotron home">
						<div class="container text-center">
							<h2>Modul Persediaan Barang	</h2>
						
							<p>&nbsp;</p>
							
							
						</div>
					</div>
				<?php endif; ?>
				
			</div>
			
		</div>
		
	