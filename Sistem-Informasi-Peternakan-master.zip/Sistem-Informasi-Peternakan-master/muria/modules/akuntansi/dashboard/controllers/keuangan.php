<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
* 
*/
class Keuangan extends MX_Controller {
	function __construct(){
		parent::__construct();
	}
	public function index()
	{
		
	}
}

/* End of file keuangan.php */
/* Location: ./ */
 ?>