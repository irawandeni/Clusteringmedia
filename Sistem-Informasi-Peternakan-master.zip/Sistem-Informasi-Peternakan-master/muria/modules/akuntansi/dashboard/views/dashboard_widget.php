
    <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                
            <a class="" href="#modal-id" data-toggle="modal" data-load="<?php echo domain() ?>acc/rekening" data-table="<?php echo domain() ?>acc/rekening/tables" data-remote-target="#modal-id .modal-body">
           
                <div class="widget style1 navy-bg">
                        <div class="row">
                            <div class="col-xs-12 text-center">
                            <!-- <i class="fa fa-cubes fa-5x"></i> -->
                            <img src="<?php echo assets_url() ?>/images/account_data.png">
                            </div>
                            <div class="col-xs-12 text-center">
                                <span>Accounts</span>
                                <h3 class="font-bold">Daftar Akun No. Perkiraan</h3>
                            </div>
                        </div>
                </div>
            </a>
    </div>
    <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                
            <a class="" href="#modal-id" data-toggle="modal" data-load="<?php echo domain() ?>fin/cash/getdatatables" data-table="<?php echo domain() ?>fin/cash/tables" data-remote-target="#modal-id .modal-body">
           
                <div class="widget style1 red-bg">
                        <div class="row">
                            <div class="col-xs-12 text-center">
                            <!-- <i class="fa fa-cubes fa-5x"></i> -->
                            <img src="<?php echo assets_url() ?>/images/accounting5.png">
                            </div>
                            <div class="col-xs-12 text-center">
                                <span>Book</span>
                                <h3 class="font-bold">Buku Besar</h3>
                            </div>
                        </div>
                </div>
            </a>
    </div>
    <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
            	
            <a class="" href="#modal-id" data-toggle="modal" data-load="<?php echo domain() ?>fin/cash/getdatatables" data-table="<?php echo domain() ?>fin/cash/tables" data-remote-target="#modal-id .modal-body">
           
                <div class="widget style1 blue-bg">
                        <div class="row">
                            <div class="col-xs-12 text-center">
                            <!-- <i class="fa fa-cubes fa-5x"></i> -->
                            <img src="<?php echo assets_url() ?>/images/speech.png">
                            </div>
                            <div class="col-xs-12 text-center">
                                <span>Journal</span>
                                <h3 class="font-bold">Transaksi Jurnal Umum </h3>
                            </div>
                        </div>
                </div>
            </a>
    </div>