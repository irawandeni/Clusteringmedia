<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if($_SERVER['HTTP_HOST']=='localhost'):
$config['assets_url'] = "http://".$_SERVER['HTTP_HOST']."/ci-muria/assets/";
else:
$config['assets_url'] = "http://sim.muriaps.com/assets/";
endif;
/* End of file assets.php */
/* Location: ./application/config/assets.php */