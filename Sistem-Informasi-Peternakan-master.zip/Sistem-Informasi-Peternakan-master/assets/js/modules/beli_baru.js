$(document).ready(function(){



  