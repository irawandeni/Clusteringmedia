<?php
//$db = new mysqli("localhost","u276036398_akuan","N4fA53ng7zXW","u276036398_akua");

$db = new mysqli("localhost","root","","akua");
?>