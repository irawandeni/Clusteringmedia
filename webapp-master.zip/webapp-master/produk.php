<div class="container" style="text-align: center;">
    <div class="row" style='margin-top: 40px'>
        <div style="text-align: left;font-size: 51px; z-index:-9;margin-left: -67px;margin-top: -37px;"><b>PILIH TERNAK</b></div>
        <h2 style="color:white;"><b>Produk</b></h2>
        <div class="col-sm-8 col-md-6">
            <div style='margin-left: -148px;margin-top: -25px;'>
                <img  src="assets/images/Produk 1.png" />
                <div class="caption" style='margin-top: -27px;'>
                    <h3><center style='font-size: 31px'>DOMBA</center></h3>
                </div>
            </div>
        </div>
        <div class="col-sm-8 col-md-6">
            <div  style='margin-left: 90px; margin-top: -30px'>
                <img  src="assets/images/Produk 2.png" />
                <div class="caption" style='margin-top: -41px'>
                    <h3><center style='margin-left: 53px;font-size: 31px;'>KAMBING</center></h3>
                </div>
            </div>
        </div>
    </div>
</div>
