<div class="container">
    <div class="row" style="margin-top: 20px;margin-left: 20px;">
      
        <form action="service/investor/login.php" method="POST">
                <div class="form-group">
                    <input type="email" class="form-control" name="email" id="emaillogin" placeholder="Email">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="password" id="passwordlogin" placeholder="Password">
                </div>
                <button type="submit" name="login" class="btn btn-primary">Login</button>
            </form>
    </div>
</div>
<script src="Controller/RegistrasiController.js"></script>