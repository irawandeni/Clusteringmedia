Aplikasi Akuanusa.com adalah aplikasi untuk management ternak kambing berbasis website menggunakan
technology angularjs 1 dan php mysql