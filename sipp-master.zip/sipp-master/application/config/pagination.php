<?php
  $config['full_tag_open'] = '<ul id=pagination>';
  $config['full_tag_close'] = '</ul>';
  $config['cur_tag_open'] = '<li class=active>';
  $config['cur_tag_close'] = '</li>';
  $config['num_tag_open'] = '<li class="paging">';
  $config['num_tag_close'] = '</li>';
  $config['next_link'] = '&rsaquo;';
  $config['prev_link'] = '&lsaquo;';
  $config['last_link'] = '&raquo;';
  $config['first_link'] = '&laquo;';
  $config['next_tag_open']= '<li class="paging">';
  $config['next_tag_close']= '</li>';
  $config['anchor_class']= 'page_link';
?>