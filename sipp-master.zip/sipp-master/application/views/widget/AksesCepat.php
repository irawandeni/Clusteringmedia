<table class="quick-access-w">
				<tr>
					<td width="50%">
						<a href="<?=base_url()?>stok_pakan">
							<img src="<?=base_url()?>assets/images/qa_icn/sp.png">
							Stok Pakan<br/>
							<abbr>catatan stok pakan</abbr>
						</a>
					</td>
					<td width="50%">
						<a href="<?=base_url()?>stok_pakan/baru">
							<img src="<?=base_url()?>assets/images/qa_icn/sp+.png">
							Tambah Stok<br/>
							<abbr>tambah stok pakan</abbr>
						</a>
					</td>
				</tr>
				<tr>
					<td>
						<a href="<?=base_url()?>jenis_pakan">
							<img src="<?=base_url()?>assets/images/qa_icn/jp.png">
							Jenis Pakan <br/>
							<abbr>daftar & stok jenis pakan</abbr>
						</a>						
					</td>
					<td>
						<a href="<?=base_url()?>jenis_pakan/baru">
							<img src="<?=base_url()?>assets/images/qa_icn/jp+.png">
							Tambah Jenis<br/>
							<abbr>tambah jenis pakan</abbr>
						</a>
					</td>
				</tr>
				<tr>
					<td>
						<a href="<?=base_url()?>pakai_pakan">
							<img src="<?=base_url()?>assets/images/qa_icn/pp.png">
							Pemakaian Pakan<br/>
							<abbr>catatan pemakaian pakan</abbr>
						</a>
					</td>
					<td>
						<a href="<?=base_url()?>pakai_pakan/baru">
							<img src="<?=base_url()?>assets/images/qa_icn/pp+.png">
							Pakai Pakan<br/>
							<abbr>pakai pakan</abbr>
						</a>
					</td>
				</tr>
				<tr>
					<td>
						<a href="<?=base_url()?>user/profile">
							<img src="<?=base_url()?>assets/images/qa_icn/user.png">
							Profile<br/>
							<abbr>edit profile anda</abbr>
						</a>
					</td>
					<td>
						<a href="<?=base_url()?>tentang">
							<img src="<?=base_url()?>assets/images/qa_icn/about.png">
							Tentang<br/>
							<abbr>tentang aplikasi ini</abbr>
						</a>
					</td>
				</tr>
				<tr>
					<td>
						<a href="<?=base_url()?>user/logout">
							<img src="<?=base_url()?>assets/images/qa_icn/logout.png">
							Keluar<br/>
							<abbr>keluar dari aplikasi ini</abbr>
						</a>
					</td>
					<td></td>
				</tr>
				
			</table>
