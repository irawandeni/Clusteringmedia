<span class="lefty">&copy; mchuluq &bull; rendered in <strong>{elapsed_time}</strong> seconds &bull; <abbr id="console"></abbr></span><span class="righty">Praktek Kerja Nyata UYP 2012</span>
