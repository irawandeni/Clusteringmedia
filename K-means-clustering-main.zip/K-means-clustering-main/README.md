# Metode-K-means-clustering

Clustering status gizi menggunakan PHP 
